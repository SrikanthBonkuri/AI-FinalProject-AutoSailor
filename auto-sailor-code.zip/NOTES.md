## NOTES FOR 3JS related stuffs

### basics
Positions are denoted by THREE.Vector3 objects. In the current setup, x corresponds to left/right, y corresponds to up/down, and z corresponds to forward/back.

Headings are given in terms of unit vectors, so to actually use them for anything geometric you'll need to convert to an angle (in radians)

### simple loading of 3D asset
```
let boat;
const loader = new GLTFLoader();
loader.load(boat_v001, (gltf) => {
    boat = gltf.scene;

    boat.scale.set(100, 100, 100);
    
    scene.add(boat);  
});
```


### Object with simple position and material assignment
```
const geometry = new THREE.SphereGeometry(1);  
const material = new THREE.MeshPhysicalMaterial({
    color: 0x00ff00;
    metalness: 1,            
    roughness: 0.3,
    reflectivity: 1,
});
const sphr = new THREE.Mesh(geometry, material);
sphr.castShadow = true;
sphr.position.set(10,0,0);
scene.add(sphr);
```


## Vector calculations
```
let alpha = 1;  // Weight for the boat's own direction
let beta = 0.5;  // Weight for the wind
let gamma = 0.3;  // Weight for the water current

let resultantDirection = direction.clone().multiplyScalar(alpha)
                         .add(wind.clone().multiplyScalar(beta))
                         .add(waterCurrent.clone().multiplyScalar(gamma));

this.position.add(resultantDirection.normalize().multiplyScalar(this.currentSpeed));
console.log(this.position);

this.boatGeo.position.copy(this.position);
```


## Sail animating towards wind vector
```
updateSail(windVec) {
    // Get the boat's forward direction
    let boatDirection = this.getHeading();

    // Compute the angle between the boat's forward direction and the wind direction
    let targetAngle = boatDirection.angleTo(windVec);

    // Determine the direction of rotation (clockwise or counter-clockwise) based on the cross product
    let cross = new THREE.Vector3().crossVectors(boatDirection, windVec);
    if (cross.y < 0) {
        targetAngle = -targetAngle;
    }

    // Adjust for the sail's setup (make it point with the wind instead of into the wind)
    targetAngle += Math.PI;

    // Easing factor (you can adjust this value)
    const easingFactor = 0.05;
    // console.log(this.mastCtrl);
    
    let angleDifference, angleAdjustment;
    // Compute the difference between the current rotation and the target rotation
    if(this.mastCtrl == null){
    } else {
        // angleDifference = targetAngle - this.mastCtrl.rotation.y;
        angleDifference = hlpf.shortestAngleDifference(this.mastCtrl.rotation.y, targetAngle);

        // Apply easing to the rotation adjustment
        angleAdjustment = angleDifference * easingFactor;

        // Update the sail's rotation
        this.mastCtrl.rotation.y += angleAdjustment;
    }
}   
```