# Sailboat Game README file


[Figma board here! ](https://www.figma.com/file/ewcZazuliwcIUrkC5BtpgF/%E2%9B%B5SailingGame?type=design&node-id=0-1&mode=design&t=FC6n9sVVjk8q620n-0)

## What's in the project currently? ⛵

`README.md`: you are here. 

`index.html`: just loads index.js and style.css

`style.css`: basic styles

`index.js`: initiates everything...
-  setup main world 
    - scene
    - temp camera
    - temp lights
    - test fog
    - rendering
    - animation loop
    - basic boat controls
    - orbit mouse controls
-  importing `boat.js` object
    - loads boat from .glb file
    - inits simple boat vars
    - boat updateFunctions
    - essentially everything boat related
    
-  `wind.js`:
    - simple wind vector with debug arrow
    - hard coded using d2r() degree2radians on X/Z axis

### js folder:
`wind.js`- wind object
`boat.js` - boat object
`agent.js` - AI agents for sailing the boat

`forces.js` - makes static lookups for boat-wind interaction
`sailMatrix.tsv` - used to generate statics in `forces.js`

`helperFunctions.js` - collection of helpers mostly used in index and boat (maybe wind)

## Important to run localy!

Must install...
- [Node.js](https://nodejs.org/en/download) (v19.4.0)
- install node_modules (run `npm` commands from project folder) (npm v9.2.0)
```
npm i 
```
- [Parcel Bundler](https://parceljs.org/)

```
npm install -g parcel-bundler
```

- then you should just be able to run. 

```
npm run start
```

## Controls 🕹️

**A/D**: Boat "rudder" Left/Right

**I/O**: Move sail In/Out

**1**: Default camera
**2**: Follow camera

**6**: Reflex Agent
**7**: Greedy Agent
**8**: DLS Agent
**9**: A* Agent
**0**: Manual Controls

## Next 🏗️

We can add stuff in `TODO.md` or in the [Figma board](https://www.figma.com/file/ewcZazuliwcIUrkC5BtpgF/%E2%9B%B5SailingGame?type=design&node-id=0-1&mode=design&t=FC6n9sVVjk8q620n-0)