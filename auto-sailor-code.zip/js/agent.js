import * as THREE from 'three';

import Boat from './boat';
import Forces from './forces';
import * as helpers from './helperFunctions' ;

/**
 * Minimal Boat object so that Agent can clone it and figure out where it will be next without
 * moving the actual boat
 */
class GhostShip extends Boat {
    constructor(boat) {
        super(null, boat.position.clone(), boat.heading, boat.currentSpeed, null, true);
        this.boatGeo = boat.boatGeo.clone();
        this.mastCtrl = boat.mastCtrl.clone();
        this.targetSpeed = boat.targetSpeed;
        this.topSpeed = boat.topSpeed;
        this.sheet = boat.sheet;
        this.sailSide = boat.sailSide;
    }
}

/**
 * Permissible actions for Agent
 */
const Actions = {
    AHEAD : 0, // go straight ahead
    LEFT : 1, // boat turn left
    RIGHT : -1, // boat turn right
};

/**
 * AI Agent Class
 * TODO: subclass to different types instead of everything living in one giant file
 */
class Agent {
    constructor() {
        this.targetQueue = [];
        this.targetPosition = null; // target position for boat
        this.searchRadius = 10;     // how close to get for target to be reached
        this.minSpeed = 0.04;       // we don't want to be slower than this
        this.actionList = [];       // action list to perform
        this.combinedActionList = [];

    }

    /* ================ SHARED ================ */

    /**
     * Runs the Auto Sailor agent
     * @param {Boat} boat - the object being moved
     * @param {wind} wind - wind vector
     * @param {} beacons
     * @param {String} agentType
     */
    executeAgent(boat, wind, beacons, agentType) {
        for (let beacon of beacons) {
            this.targetQueue.push(beacon.position.clone());
        }

        let boatClone = new GhostShip(boat);

        for (let targetPosition of this.targetQueue) {
            this.targetPosition = targetPosition;

            switch (agentType) {
                case 'reflex':
                    this.reflexAgent(boatClone, wind);
                    break;
                case 'greedy':
                    this.greedyAgent(boatClone, wind);
                    break;
                case 'dls':
                    this.dlsAgent(boatClone, wind);
                    break;
                case 'aStar':
                    this.aStarAgent(boatClone, wind);
                    break;
            }

            [boatClone] = this.getSuccessor(boatClone, wind, this.actionList);
            this.combinedActionList.push(...this.actionList);
            this.actionList = [];
        }
        console.log("Total path cost: ", this.combinedActionList.length, "actions.");
    }

    /**
     * @brief executes the next action in the combined action list
     * @param {*} boat - the object being moved
     * @param {*} wind - wind vector
     * @returns 
     */
    performNextAction(boat, wind){
        if (this.combinedActionList.length > 0) {
            let nextAction = this.combinedActionList.shift();
            this.reflexAdjustHeading(boat, nextAction);  
            this.reflexAdjustSheet(boat, wind.heading);
            return true;
        }
        return false;
    }

    /**
     * @brief Clears all values back to defaults
     */
    reset(){
        this.targetQueue =  [];
        this.targetPosition = null;
        this.actionList = [];
        this.combinedActionList = [];
    }
  
    /**
     * Adjusts the passed boat's heading based on the passed action.
     * @param {Boat} boat - object to adjust 
     * @param {Actions} action - action to do (Left, Right, Ahead)
     */
    reflexAdjustHeading(boat, action) {
        // Calculate the heading change based on the action
        const headingChange = Actions[action] * boat.lrTrnSpeed;

        // Update the boat's heading
        boat.updateHeading(headingChange);
    }

    /**
     * Adjusts the sail angle to the optimal angle based on static lookup in Forces
     * @param {Boat} boat - vessel to adjust
     * @param {THREE.Vector3} windHeading - wind direction
     * @returns void
     */
    reflexAdjustSheet(boat, windHeading) {
        const windBoatAngle = boat.getWindBoatAngle(windHeading);
        const sailSide = boat.getSailSide(windHeading);
        // lookup is sided, target must be absoluted
        const targetSheet = Math.abs(Number(Forces.getBestSheetValue(windBoatAngle, sailSide)));

        // early return conditions:
        if(Math.abs(targetSheet - boat.sheet) < boat.sheetAdjustment/2) { // within adjustment amt
            return;
        }
            
        // adjust the sheet
        if(targetSheet - boat.sheet > 0) { // less than target
            boat.sheetOut();
        } 
        else {                           // greater than target
            boat.sheetIn(windHeading)
        }
    }

    /**
     * Checks whether the boat object has reached the target point
     * @param {Boat} boat - the object being moved
     * @returns whether the boat has gotten within the agent-defined search radius of target
     */
    isGoalState(boat){
        return boat.position.distanceTo(this.targetPosition) < this.searchRadius;
    }

    /**
     * Takes a boat object, clones it, does a series of actions to it, and passes it back
     * to the caller for evaluation.
     * @param {Boat} boat - boat object to clone
     * @param {Wind} wind - wind vector
     * @param {List} actionSequence  - actions to try
     * @returns a clone of the passed boat that has been mutated by the passed action list
     */
    getSuccessor(boat, wind, actionSequence) {
        let boatClone = new GhostShip(boat);
    
        // Simulate actions in sequence and check for goal state
        for (let i = 0; i < actionSequence.length; i++) {
            let action = actionSequence[i];
            this.reflexAdjustHeading(boatClone, action);
            this.reflexAdjustSheet(boatClone, wind.heading);
    
            // Update the boat clone's state
            boatClone.updateSail(wind.heading);
            boatClone.updateSpeedFromWind(wind);
            boatClone.updateSpeed(wind.heading, wind.heading);
    
            // Check if goal state is reached
            if (this.isGoalState(boatClone)) {
                return [boatClone, actionSequence.slice(0, i + 1)];
            }
        }
    
        return [boatClone, actionSequence];
    }

    /**
     * Calculates the component of the passed boat actual movement vector that is towards the target.
     * This is done by projecting the velocity vector onto the vector between the boat and target.
     * NOTE: this is the CURRENT speed
     * @param {Boat} boat - object to evaluate
     * @returns radial speed (as a double)
     */
    calculateRadialSpeed(boat) {
        let velocityVector = new THREE.Vector2(boat.getHeading().x, boat.getHeading().z).multiplyScalar(boat.currentSpeed);
        let directionToTarget = new THREE.Vector2(this.targetPosition.x - boat.position.x, this.targetPosition.z - boat.position.z);
        let dotProduct = velocityVector.dot(directionToTarget);
    
        // Project the velocity onto the direction to target
        let projection = dotProduct / directionToTarget.lengthSq();
        let radialVelocity = directionToTarget.multiplyScalar(projection);
    
        let radialSpeed = radialVelocity.length();
        if (dotProduct < 0) {
            radialSpeed *= -1;
        }
    
        return radialSpeed;
    }

    /* ================ END SHARED ================ */

    /* ================ REFLEX AGENT ================ */

    /**
     * Simple reflex agent, informed of its upwind limitations.
     * Successfully navigates downwind.
     * Navigates upwind in a primitive way.
     * @param {Boat} boat 
     * @param {Wind} wind
     */
    reflexAgent(boat, wind) {
        if (this.targetPosition === null) { return; }
        
        let boatClone = new GhostShip(boat);

        while(!this.isGoalState(boatClone)){ 
            const sailSide = boatClone.getSailSide(wind.heading);
            let actionOrder;
            if (sailSide === -1) {
                actionOrder = ['AHEAD', 'LEFT', 'RIGHT'];
            } else {
                actionOrder = ['AHEAD', 'RIGHT', 'LEFT'];
            }

            // Check angle to target to see if tacking is viable
            const targetWindAngle = this.targetWindAngle(boatClone, wind);
            if (targetWindAngle > Math.PI / 4 && targetWindAngle < Math.PI * 7 / 4){
                // Falling off is encouraged if current speed is low
                if (boatClone.currentSpeed < this.minSpeed && sailSide === -1){
                    actionOrder = ['LEFT', 'AHEAD', 'RIGHT'];
                } else if (boatClone.currentSpeed < this.minSpeed && sailSide === 1) {
                    actionOrder = ['RIGHT', 'AHEAD', 'LEFT'];
                } 
            } else { // If tacking is not viable, restrict available actions
                const angleToWind = boatClone.getWindAngle(wind);
                // Angle too close to wind for a reflex agent, must go ahead or fall off
                if (angleToWind < Math.PI / 4 || angleToWind > Math.PI * 7 / 4){
                    if (sailSide === -1){
                        actionOrder = ['AHEAD', 'LEFT'];
                    } else {
                        actionOrder = ['AHEAD', 'RIGHT'];
                    }
                }
            }

            let maxRadialSpeed = -Infinity;
            let bestAction = actionOrder[0];
            let tempBoatClone;
            const turnInhibitor = 0.0001;
        
            // Evaluate available actions and select the one that maximizes the
            // boat's current speed towards the target
            for (let action of actionOrder) {
                [tempBoatClone] = this.getSuccessor(boatClone, wind, [action]);
                let radialSpeed = this.calculateRadialSpeed(tempBoatClone);
        
                // Encourage turning at low speeds, discourage at higher speeds
                if (boatClone.currentSpeed < this.minSpeed && radialSpeed > maxRadialSpeed) {
                    maxRadialSpeed = radialSpeed;
                    bestAction = action;
                } else if (radialSpeed > maxRadialSpeed + turnInhibitor){
                    maxRadialSpeed = radialSpeed;
                    bestAction = action;
                }
            }
            
            this.actionList.push(bestAction);
            [boatClone] = this.getSuccessor(boatClone, wind, [bestAction]);
        }
        console.log("Path to target found with: ", this.actionList.length, "actions!");
    }

    /* ================ END REFLEX AGENT ================ */

    /** ================ DLS SEARCH AGENTS ===============*/

    /**
     * Greedy DLS agent.
     * Creates a list of actions to take using greedy decision making.
     * Uses distance to target as the heuristic.
     * @param {Boat} boat - object to move
     * @param {Wind} wind - wind vector
     */
    greedyAgent(boat, wind) {
        if (this.targetPosition === null) { return; }

        let boatClone = new GhostShip(boat);
        let depthLimit = 240;
        let penalty = 0.2;
    
        while (!this.isGoalState(boatClone)) {
            // Adjust depthLimit based on the distance to the target
            let distance = boatClone.position.distanceTo(this.targetPosition);
            if (this.actionList.length > 0){
                depthLimit = distance > 15 ? 120 : 30;
            }
            
            let actionSequence = this.findBestActionSequence(boatClone, wind, depthLimit, penalty);
    
            // Apply the best action sequence to the boat clone
            [boatClone, actionSequence]= this.getSuccessor(boatClone, wind, actionSequence);
    
            // Append the best action sequence to the actionList
            this.actionList.push(...actionSequence);
        }
        console.log("Path to target found with: ", this.actionList.length, "actions!");
    }

    /**
     * DLS search agent.
     * Evaluates states of limited depth while varying the heuristic function.
     * Uses distance to target as a heuristic, with a penalty for moving slowly.
     * @param {Boat} boat - object to move
     * @param {Wind} wind - wind vector
     */
    dlsAgent(boat, wind) {
        if (this.targetPosition === null) { return; }

        let boatClone = new GhostShip(boat);
        let depthLimit = 240;
    
        while (!this.isGoalState(boatClone)) {
            // Adjust depthLimit based on the distance to the target
            let distance = boatClone.position.distanceTo(this.targetPosition);
            if (this.actionList.length > 0){
                depthLimit = distance > 15 ? 120 : 30;
            }

            const penalties = [0.1, 0.2, 0.4];
            let bestScore = Infinity;
            let nextBoatClone;
            let bestActionSequence = [];
            for (let penalty of penalties) {
                let actionSequence = this.findBestActionSequence(boatClone, wind, depthLimit, penalty);
                
                // Apply the action sequence to the boat clone
                [nextBoatClone, actionSequence] = this.getSuccessor(boatClone, wind, actionSequence);
                let score = this.greedyHeuristic(nextBoatClone, penalty);

                if (score < bestScore) {
                    bestActionSequence = actionSequence;
                }
            }
    
            // Apply the best action sequence to the boat clone
            [boatClone] = this.getSuccessor(boatClone, wind, bestActionSequence);
    
            // Append the best action sequence to the actionList
            this.actionList.push(...bestActionSequence);
        }
        console.log("Path to target found with: ", this.actionList.length, "actions!");
    }

    /**
     * Generates the best action sequence for DLS and greedy DLS
     * @param {Boat} boat - boat object
     * @param {Wind} wind - wind vector
     * @param {int} depthLimit - how deep to look
     * @param {double} penalty - deterrent from slow movement 
     * @returns list of actions to take
     */
    findBestActionSequence(boat, wind, depthLimit, penalty) {
        let bestScore = Infinity;
        let bestActionSequence = [];
    
        // Evaluate action sequences
        for (let actionKey in Actions) {
            for (let count = 1; count <= depthLimit; count++) {
                let actionSequence = Array(count).fill(actionKey);
                actionSequence = actionSequence.concat(Array(depthLimit - count).fill('AHEAD'));
                let [boatClone, partialActionSequence] = this.getSuccessor(boat, wind, actionSequence);
                let score = this.greedyHeuristic(boatClone, penalty);
    
                if (score < bestScore) {
                    bestScore = score;
                    bestActionSequence = partialActionSequence;
                }
    
                if (actionKey === 'AHEAD') {
                    break;
                }
            }
        }
        
        return bestActionSequence;
    }

    /**
     * Heuristic function that calculates distance to target with 
     * an adjustable penalty for moving slowly.
     * Used for Greedy DLS and DLS.
     * @param {Boat} boat - object to move
     * @param {double} penalty - deterrent from slow movement
     * @returns distance to target
     */
    greedyHeuristic(boat, penalty) {
        let distance = boat.position.distanceTo(this.targetPosition);
        penalty = boat.targetSpeed > this.minSpeed ? 0 : penalty;
        
        return distance * (1 + penalty);
    }
    /** ================ END DLS SEARCH ===============*/

    /* ================ A* SEARCH ===============*/

    /**
     * Performs A* search.
     * Creates a list of actions to take.
     * @param {Boat} boat - boat object
     * @param {Wind} wind - wind object
     */
    aStarAgent(boat, wind) {
        if (this.targetPosition === null) { return; }

        // If tacking unnecessary, delegate to reflex agent
        let targetAngle = this.targetWindAngle(boat, wind);
        if (targetAngle > Math.PI / 4 && targetAngle < Math.PI * 7 / 4){
            this.reflexAgent(boat, wind);
            return;
        }
        
        // Otherwise perform A* search
        let priorityQueue = new MinHeap();
        priorityQueue.insert({
            boatClone: new GhostShip(boat), 
            actionSequence: [],
            backwardCost: 0,
            forwardCost: this.pathHeuristic(boat)
        });
    
        while (!priorityQueue.isEmpty()) {
            let { boatClone, actionSequence } = priorityQueue.extractMin();
    
            if (this.isGoalState(boatClone)) {
                this.actionList = actionSequence;
                console.log("Path to target found with: ", this.actionList.length, "actions!");
                return;
            }
    
            // Add states for LEFT and RIGHT action paths
            let leftState = this.expandState(boatClone, wind, 'LEFT', actionSequence);
            let rightState = this.expandState(boatClone, wind, 'RIGHT', actionSequence);
    
            // Push expanded states to the queue
            priorityQueue.insert(leftState);
            priorityQueue.insert(rightState);
        }
    }
    
    /**
     * Expands an A* search state.
     * @param {Boat} boatClone - the boat object to clone and manipulate
     * @param {Wind} wind - the wind vector
     * @param {Actions} direction - the action
     * @param {List} parentActionSequence - list of actions to take
     * @returns a state for A* search
     */
    expandState(boatClone, wind, direction, parentActionSequence) {
        let nextBoatClone = new GhostShip(boatClone);
        let prevBoatClone = nextBoatClone;
        let actionSequence = [...parentActionSequence];
        let previousSpeed = this.radialTargetSpeed(boatClone);
        let sailSideCondition = direction === 'LEFT' ? -1 : 1;
    
        while (true) {
            prevBoatClone = nextBoatClone;
            [nextBoatClone] = this.getSuccessor(nextBoatClone, wind, [direction]);
            let currentSpeed = this.radialTargetSpeed(nextBoatClone);
            let angleToTargetValue = this.angleToTarget(nextBoatClone);
    
            if (nextBoatClone.getSailSide(wind.heading) === sailSideCondition && 
                currentSpeed < previousSpeed && angleToTargetValue < Math.PI / 2) {
                nextBoatClone = prevBoatClone;
                break;
            }
            actionSequence.push(direction);
            previousSpeed = currentSpeed;
        }
    
        // Append 'AHEAD' actions to reduce future number of expansions
        // Scales with distance to target
        const distance = nextBoatClone.position.distanceTo(this.targetPosition);
        const aheadActions = distance > 30 ? 60 : distance > 15 ? 30 : 15
        const aheadSequence = Array(aheadActions).fill('AHEAD');
        actionSequence = actionSequence.concat(aheadSequence);
        [nextBoatClone] = this.getSuccessor(nextBoatClone, wind, aheadSequence);
        let nextForwardCost = this.pathHeuristic(nextBoatClone);
    
        return {
            boatClone: nextBoatClone,
            actionSequence: actionSequence,
            backwardCost: actionSequence.length,
            forwardCost: nextForwardCost
        };
    }
    
    /**
     * Calculates the angle between the boat-target vector and the wind vector.
     * Used in A* search.
     * @param {Boat} boat - the boat object to reference
     * @param {Wind} wind - the wind object
     * @returns angle (double) (radians)
     */
    targetWindAngle(boat, wind) {
        // Calculate the vector from the boat's position to the target position in the X-Z plane
        let directionToTarget = new THREE.Vector2(
            this.targetPosition.x - boat.position.x, 
            this.targetPosition.z - boat.position.z
        ).normalize();
    
        // Get the wind direction as a Vector3 and project it onto the X-Z plane as a Vector2
        let windDirectionVector3 = wind.getDirection(); 
        let windDirection = new THREE.Vector2(-windDirectionVector3.x, -windDirectionVector3.z).normalize();
    
        // Calculate the angle between the direction to the target and the wind direction
        let angle = Math.atan2(directionToTarget.y, directionToTarget.x) - Math.atan2(windDirection.y, windDirection.x);
    
        // Normalize the angle to the range [0, 2π)
        angle = (angle + 2 * Math.PI) % (2 * Math.PI);
    
        return angle;
    }

    /**
     * Calculates the angle from the boat heading to the target point.
     * Used in A* search.
     * @param {Boat} boat 
     * @returns angle (double) (in radians)
     */
    angleToTarget(boat) {
        let boatHeadingVector = new THREE.Vector2(boat.getHeading().x, boat.getHeading().z).normalize();
        let directionToTarget = new THREE.Vector2(this.targetPosition.x - boat.position.x, this.targetPosition.z - boat.position.z).normalize();
    
        // Calculate the angle between the boat's heading and the direction to target
        let angle = Math.acos(boatHeadingVector.dot(directionToTarget));

        return Math.abs(angle);
    }
    
    /**
     * Heuristic function for A*
     * @param {Boat} boat 
     * @returns estimated forward cost
     */
    pathHeuristic(boat){
        let distance = boat.position.distanceTo(this.targetPosition);
        let speed = this.calculateRadialSpeed(boat);
        if (speed > this.minSpeed){
            return distance / speed;
        }
        return distance / this.minSpeed;
    }

    /**
     * Calculates the component of the passed boat target movement vector that is towards the target.
     * This is done by projecting the velocity vector onto the vector between the boat and target.
     * NOTE: this is the TARGET speed, not the CURRENT speed
     * @param {Boat} boat - object to evaluate
     * @returns radial speed (as a double)
     */
    radialTargetSpeed(boat) {
        let velocityVector = new THREE.Vector2(boat.getHeading().x, boat.getHeading().z).multiplyScalar(boat.targetSpeed);
        let directionToTarget = new THREE.Vector2(this.targetPosition.x - boat.position.x, this.targetPosition.z - boat.position.z);
        let dotProduct = velocityVector.dot(directionToTarget);
    
        // Project the velocity onto the direction to target
        let projection = dotProduct / directionToTarget.lengthSq();
        let radialVelocity = directionToTarget.multiplyScalar(projection);
    
        let radialSpeed = radialVelocity.length();
        if (dotProduct < 0) {
            radialSpeed *= -1;
        }
    
        return radialSpeed;
    }  

    /* ================ END A* SEARCH ===============*/

}

/**
 * Data structure for A* search agent
 */
class MinHeap {
    constructor() {
        this.heap = [];
    }

    /**
     * Insert state to heap
     * @param {Tuple} state - For A*, consists of boatClone, wind, action, actionSequence
     */
    insert(state) {
        this.heap.push(state);
        let current = this.heap.length - 1;
        while (current > 0) {
            let parent = Math.floor((current - 1) / 2);
            if (this.lessThan(this.heap[current], this.heap[parent])) {
                [this.heap[current], this.heap[parent]] = [this.heap[parent], this.heap[current]];
                current = parent;
            } else {
                break;
            }
        }
    }

    /**
     * Pops the minimum value from the heap and returns the value
     * @returns the minimum value from the heap
     */
    extractMin() {
        if (this.heap.length === 0) return null;
        [this.heap[0], this.heap[this.heap.length - 1]] = [this.heap[this.heap.length - 1], this.heap[0]];
        let min = this.heap.pop();
        this.heapify(0);
        return min;
    }

    /**
     * Sorts the heap
     * @param {int} index - index to sort at
     */
    heapify(index) {
        let left = 2 * index + 1;
        let right = 2 * index + 2;
        let smallest = index;

        if (left < this.heap.length && this.lessThan(this.heap[left], this.heap[smallest])) {
            smallest = left;
        }
        if (right < this.heap.length && this.lessThan(this.heap[right], this.heap[smallest])) {
            smallest = right;
        }
        if (smallest !== index) {
            [this.heap[smallest], this.heap[index]] = [this.heap[index], this.heap[smallest]];
            this.heapify(smallest);
        }
    }

    /**
     * Determines whether a state is less than another based on calculated heuristic
     * @param {Tuple} stateA - first to compare
     * @param {Tuple} stateB - second to compare
     * @returns whether state A is less than state B
     */
    lessThan(stateA, stateB) {
        return stateA.backwardCost + stateA.forwardCost < stateB.backwardCost + stateB.forwardCost;
    }

    /**
     * Is the heap empty
     * @returns bool: size of heap == 0
     */
    isEmpty() {
        return this.heap.length === 0;
    }
}

export default Agent;