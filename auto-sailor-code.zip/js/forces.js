/**
 * A collection of static members and functions related to forces. Gets initialized
 * once and then is accessed through the class name (e.g. Forces.getHeadingMultiplier())
 */
export default class Forces {
    // data structures for sail force spreadsheet lookup
    static headingLookupMap = new Map(); // 0 = upwind, 180 = downwind
    static degLookup = [];               // convenience for interpolating
    static sheetLookup = [];             // not currently used

    // lookup for best sheet length for given sail angle
    static bestSheetMap = new Map();

    /**
     * @brief Initializes above static maps and arrays from a file
     */
    static{
        const fs = require('fs');
        try {
            const data = fs.readFileSync('js/sailMatrix.tsv', 'utf8');
            //console.log(data); // for debug

            // get lines, then header column
            const lines = data.split('\n');
            Forces.degLookup = lines[0].split('\t');
            Forces.degLookup.shift();
                     
            // walk through to get values
            for(let i = 1; i < lines.length; i++){
                // split row and save the sheet length val
                let sheetLine = lines[i].split('\t');
                Forces.sheetLookup.push(sheetLine[0]);

                // build map
                for( let j = 1; j < sheetLine.length; j++){
                    let key = "(" + sheetLine[0] + "," + Forces.degLookup[j-1] + ")";
                    Forces.headingLookupMap.set( key, sheetLine[j]);
                } 
            }

            // optimal sail angles
            for(let i = 0; i < Forces.degLookup.length; i++){ // degree angle
                // initialize each degree to sheetlength 0
                let degree = Forces.degLookup[i];
                Forces.bestSheetMap.set(degree, 0);

                // get the sheet length with the best force multiplier for each agnel
                let best = 0;
                for(let j = 0; j < Forces.sheetLookup.length; j++){ // sheet length
                    let sheet = Forces.sheetLookup[j];
                    let key = "(" + sheet + "," + degree + ")";
                    let forceMultiplier = Number(Forces.headingLookupMap.get(key));

                    if(forceMultiplier > best){
                        Forces.bestSheetMap.set(degree, sheet);
                        best = forceMultiplier;

                    }
                }
            }

        } catch (err) {
            console.error(err);
        }
        
        // Forces.bestSheetMap.forEach(function(value, key){
        //     let headingKey = "(" + Math.abs(value) + "," + key + ")";
        //     let headingKeyN = "(" + -1*Math.abs(value) + "," + key + ")";
        //     console.log(headingKey, Forces.headingLookupMap.get(headingKey), Forces.headingLookupMap.get(headingKeyN));
        // });
    }

    /**
     * @brief Gets the nearest two values on the spreadsheet for the given wind-boat angle
     * (in degrees)
     * 
     * @param {double} windBoatAngle  - angle of the wind with respect to the boat
     * @returns floor, ceil of nearest deg angles
     */
    static getNearestSpreadsheetAngles(degAngle){
        // get index for nearest two degrees
        let degreeIndex1 = 0;
        let degreeIndex2 = 0;
        for(let i = 0; i < Forces.degLookup.length; i++){
            if (Forces.degLookup[i] <= degAngle%360){
                degreeIndex1 = i;
            }
        }
        degreeIndex2 = (degreeIndex1 + 1)%(Forces.degLookup.length);

        // lookup actual degree value
        return [Forces.degLookup[degreeIndex1], Forces.degLookup[degreeIndex2]];
    }

    /**
     * @brief looks up the force multiplier for the given sheet length, wind angle, and sail side
     * 
     * @param {double} sheetLength - between 0 and 1.41 in increments of 0.01
     * @param {double} windBoatAngle - angle in radians
     * @param {double} sailSide - side the sail is on
     */
    static getHeadingMultiplier(sheetLength, windBoatAngle, sailSide){
        // get the boat heading angle
        let degAngle = (windBoatAngle + Math.PI)/Math.PI*180; // to degrees 
        let sheetLength2 = 1.41*sheetLength;                  // from max 1.41 to max 2
   
        // handle symmetry
        if(sailSide == -1){
            degAngle =  Math.abs(360 - degAngle);
            sheetLength2 *= sailSide;
        }

        // get sheet
        const sheetFloor = Math.floor(10*sheetLength2)/10;
        const sheetCeil = Math.ceil(10*sheetLength2)/10;
        const sheet = sheetLength2 > 0 ? sheetCeil : sheetFloor;

        // get nearest spreasheet headers for lookup
        const [degAngleVal1, degAngleVal2] = Forces.getNearestSpreadsheetAngles(degAngle);

        // get nearest two values from spreadsheet
        const key1 = "(" + sheet + "," + degAngleVal1 + ")";
        const key2 = "(" + sheet + "," + degAngleVal2 + ")";
        const v1 = this.headingLookupMap.get(key1);
        const v2 = this.headingLookupMap.get(key2);

        // interpolate 
        const dist1 = Math.abs(degAngleVal1 - degAngle%360);
        const dist2 = Math.abs(degAngleVal2 - degAngle%360);
        const distT = Math.abs(degAngleVal2 - degAngleVal1);
        const v = dist2/distT*v1 + dist1/distT*v2;

        //debug string
        // console.log("multiplier 1: ", key1, ": ", v1,
        //             "\nmultiplier 2: ", key2, ": ", v2,
        //             "\ninterpolated: (" + sheet + "," + (degAngle%360).toFixed(2) + ")", ":", v.toFixed(2));

        return v;
    }

    /**
     * @brief Gets the sheet length that optimizes the sail force for the given wind-boat angle
     * @param {double} windBoatAngle - windBoatAngle in radians
     * @param {int} sailSide         - side of the sail on the boat (1 or -1)
     * @returns target sheet length as a double
     */
    static getBestSheetValue(windBoatAngle, sailSide){
        // get the boat heading angle
        let degAngle = (windBoatAngle + Math.PI)/Math.PI*180;

        // handle symmetry
        if(sailSide == -1){
            degAngle =  Math.abs(360 - degAngle);
        }

        // find the wind force multiplier
        let [minAngle, maxAngle] = Forces.getNearestSpreadsheetAngles(degAngle);
        let rawSheet = 0;
        if(Math.abs(minAngle - degAngle) < Math.abs(maxAngle - degAngle)){
            rawSheet = Forces.bestSheetMap.get(minAngle);
        } else {
            rawSheet = Forces.bestSheetMap.get(maxAngle);
        }

        // convert from raw sheet
        let targetSheet = rawSheet/1.41;
       
        // round and return
        return Number(targetSheet.toFixed(2));
    }

}

