import * as THREE from 'three';

//* Seed based random values
export class Rnd {
    constructor() {
      this.useA = false;
      let sfc32 = function (uint128Hex) {
        let a = parseInt(uint128Hex.substr(0, 8), 16);
        let b = parseInt(uint128Hex.substr(8, 8), 16);
        let c = parseInt(uint128Hex.substr(16, 8), 16);
        let d = parseInt(uint128Hex.substr(24, 8), 16);
        return function () {
          a |= 0; b |= 0; c |= 0; d |= 0;
          let t = (((a + b) | 0) + d) | 0;
          d = (d + 1) | 0;
          a = b ^ (b >>> 9);
          b = (c + (c << 3)) | 0;
          c = (c << 21) | (c >>> 11);
          c = (c + t) | 0;
          return (t >>> 0) / 4294967296;
        };
      };
      // seed prngA with first half of tokenData.hash
      this.prngA = new sfc32(tokenData.hash.substr(2, 32));
      // seed prngB with second half of tokenData.hash
      this.prngB = new sfc32(tokenData.hash.substr(34, 32));
      for (let i = 0; i < 1e6; i += 2) {
        this.prngA();
        this.prngB();
      }
    }
    // random number between 0 (inclusive) and 1 (exclusive)
    rnd_dec() {
      this.useA = !this.useA;
      return this.useA ? this.prngA() : this.prngB();
    }
    // random number between a (inclusive) and b (exclusive)
    rnd_num(a, b) {
      return a + (b - a) * this.rnd_dec();
    }
    // random integer between a (inclusive) and b (inclusive)
    // requires a < b for proper probability distribution
    rnd_int(a, b) {
      return Math.floor(this.rnd_num(a, b + 1));
    }
    // random boolean with p as percent liklihood of true
    rnd_bool(p) {
      return this.rnd_dec() < p;
    }
    // random value in an array of items
    rnd_choice(list) {
      return list[this.rnd_int(0, list.length - 1)];
    }
}

//* Converts degrees to Radians
export function d2r(deg){
  let result = THREE.MathUtils.degToRad(deg);
  return result;
}

//* Lerp type function to remap values
export function reMap(x, in_min, in_max, out_min, out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


//* creates a 3js text label on the position specified (ie. WindDir)
export function createTextLabel(text, position) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  ctx.font = '30px Arial';
  ctx.fillStyle = 'red';
  ctx.fillText(text, 10, 30);

  const texture = new THREE.CanvasTexture(canvas);
  const spriteMaterial = new THREE.SpriteMaterial({ map: texture });
  const sprite = new THREE.Sprite(spriteMaterial);

  sprite.position.copy(position);
  sprite.scale.set(5, 2.5, 1);  // Adjust these values to change the size of the label

  return sprite;
}

export function shortestAngleDifference(angle1, angle2) {
  let diff = (angle2 - angle1 + Math.PI) % (2 * Math.PI) - Math.PI;
  return diff < -Math.PI ? diff + 2 * Math.PI : diff;
}


export function clamp(val, min, max) {
  return Math.max(min, Math.min(val, max));
}

/**
 * Given two position vectors, calculates the heading you must set to reach
 * 'to' from 'from'
 * @param {THREE.Vector3} from  - origin point
 * @param {THREE.Vector3} to    - target point
 */
export function calculateHeading(from, to){
  return to.add(from.negate()).normalize();
}