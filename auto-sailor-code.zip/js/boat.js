import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';  // Ensure the path is correct based on your project structure
import boat_geo from '../assets/boat_v003.glb';
import * as hlpf from './helperFunctions' ;
import Forces from './forces';


/**
 * Boat object. Keeps interal states for:
 * -heading
 * -speed
 * -sheet length
 * 
 * Methods:
 * -getPosition
 * -getHeading
 * -updateHeading
 * 
 * -getSailSide
 * -updateSail
 * 
 * -estimateSheet
 * 
 * -getWindBoatAngle
 * -getBoatSailAngle
 *
 * -updateSpeed
 * -updateSpeedFromWind
 * 
 * -loadFile
 * -addToScene
 */
class Boat {
    /**
     * @brief Creates a boat 
     * 
     * @param {THREE.Scene} scn - animation scene
     * @param {THREE.Vector3} pos - boat world position
     * @param {THREE.Vector} hdng - boat heading 
     * @param {double} speed - initial speed (defaults to 0)
     * @param {*} callback - unused
     */
    constructor(scn, pos, hdng, speed = 0.0, callback, ghost = false) {
        this.mainScene = scn;
        this.boatGeo      = new THREE.Group();  // Placeholder, will be replaced once the GLB is loaded
        this.position     = pos;
        this.heading      = hdng;
        this.mastCtrl     = null;
        this.currentSpeed = speed;
        this.targetSpeed  = 0;
        this.topSpeed     = 0.25;
        this.lrTrnSpeed   = 0.05
        this.lrSailSpeed  = 0.01
        this.sheet  = 1;
        this.sheetAdjustment = 0.01
        this.sailSide = 1;

        //* just if needed
        if (callback) {
            // callback();
        }

        // Load the boat file when the Boat object is constructed
        if (!ghost) {
            this.loadFile();
        }
    }

    /**
     * loads geometries
     */
    loadFile(){
        const loader = new GLTFLoader();
        loader.load(
            boat_geo,
            (gltf) => {
                this.boatGeo = gltf.scene;  // Assign the loaded mesh to our class's mesh property
                this.boatGeo.position.copy(this.position);
                this.boatGeo.rotateY(this.heading);

                this.boatGeo.scale.set(100, 100, 100);

                this.boatGeo.traverse((child) => {

                    child.updateWorldMatrix(true);

                    if(child.name == 'mast_ctrl'){
                        this.mastCtrl = child;
                        let dir = new THREE.Vector3(1, 0, 0);
                        let length = 5;  // Length of the arrow
                        let hex = 0xff0000;  // Color of the arrow
                        
                        // let pos = this.boatGeo.position.sub(this.mastCtrl.position);
                        this.mastVec  = new THREE.ArrowHelper(dir, new THREE.Vector3(0,12,0), length,hex)
                        
                        this.mastCtrl.add(this.mastVec);

                    }
                    if(child.isMesh){
                        child.material = new THREE.MeshPhysicalMaterial({
                            side: THREE.DoubleSide,
                            color: 0x033D36,           
                            metalness: 0,            
                            roughness: 0.8,
                            reflectivity: 1,

                            // transmission: 0.9,
                        });
                        child.castShadow = true;
                        // child.receiveShadow = true; //! bug maybe check shadow map
                    }
                })

                console.log('Boat model has loaded!');

                // Call addToScene after the boat model has loaded
                this.addToScene();
                // this.getHeading();
            },
            undefined,
            (error) => {
                console.error('An error occurred while loading the model.', error);
            }
        );
    }

    /**
     * animation stuff
     */
    addToScene() {
        this.mainScene.add(this.boatGeo);
    }

    /**
     * @brief Gets the boat position
     * @returns the actual position of the boat, self.position is a lie
     */
    getPosition(){
        return this.boatGeo.position;
    }

    /**
     * @brief Gets the heading of the boat, as a length 1 vector
     * 
     * @returns the in-world direction of the boat as a normalized vector
     */
    getHeading() {
        // Define the "forward" direction in the boat's local space
        let localDirection = new THREE.Vector3(1, 0, 0);

        // Convert the local direction to world space based on the boat's current rotation
        let worldDirection = localDirection.applyQuaternion(this.boatGeo.quaternion);
        // this.heading = worldDirection.normalize();

        // Ensure the direction is normalized
        return worldDirection.normalize();
    }

    /**
     * @brief Rotates the boat
     * 
     * @param {double} val - amount to rotate (in radians)
     */
    updateHeading(val) {
        // Turning control strength relative to boat speed (the greater the speed the greater manouverability)
        let trnStr = hlpf.reMap(this.currentSpeed, 0, this.topSpeed, 0.1, 1);
        this.boatGeo.rotateY(val * trnStr);

    }

    /**
     * @brief Calculates the angle between the boat's heading and the wind direction
     * 
     * @param {*} wind 
     * @returns 
     */
    getWindAngle(wind) {
        // Get the boat's heading as a Vector3 and project it onto the X-Z plane
        let boatHeadingVector3 = this.getHeading();
        let boatHeading = new THREE.Vector2(boatHeadingVector3.x, boatHeadingVector3.z).normalize();
    
        // Get the wind direction as a Vector3 and project it onto the X-Z plane
        let windDirectionVector3 = wind.getDirection();
        // Invert the wind direction to get the direction it's coming from
        let windDirection = new THREE.Vector2(-windDirectionVector3.x, -windDirectionVector3.z).normalize();
    
        // Calculate the angle between the boat's heading and the wind's opposite direction
        let angle = Math.atan2(boatHeading.y, boatHeading.x) - Math.atan2(windDirection.y, windDirection.x);
    
        // Normalize the angle to the range [0, 2π)
        angle = (angle + 2 * Math.PI) % (2 * Math.PI);
    
        return angle;
    }    

    /**
     * @brief Gets the sail distance out from the boat centerline; either sheet length 
     *        or smaller if upwind
     * 
     * @param {THREE.Vector3} windHeading - normalized vector of wind direction
     * @returns the smaller of sheet length, sail distance to centerline
     */
    estimateSheet( windHeading){
        let boatSailAngle = this.getBoatSailAngle(windHeading) + Math.PI/2;  
        let actual = Math.abs(1.40*Math.cos(boatSailAngle).toFixed(2));

        return Math.min(actual, this.sheet);
    }

    /**
     * @brief Pulls the sheet in. If upwind, instantaneously pulls in regardless of old position
     * @param {THREE.Vector3} windHeading - normalized vector of wind direction
     */
    sheetIn(windHeading){
        // pulling in upwind acts instantaneously from current sail position
        this.sheet = (this.estimateSheet(windHeading) < this.sheet) ? 
        this.estimateSheet(windHeading) : this.sheet;

        if(this.sheet >= this.sheetAdjustment) // limit is 0 length
            this.sheet -= this.sheetAdjustment;
        else
            this.sheet = 0;
    }

    /**
     * @brief Moves the sheet out
     */
    sheetOut(){
        // magic number that prevents more than 90 degree sail angle (sqrt2)
        if(this.sheet <= 1.40) 
            this.sheet += this.sheetAdjustment;
        else 
            this.sheet = 1.41;

    }

    /**
     * @brief Gets which side of the boat the sail should be on
     * 
     * @param {THREE.Vector3} windHeading - the heading of the wind
     * @returns -1 if the left side, 1 otherwise
     */
    getSailSide( windHeading) {
        let boatDirection = this.getHeading();
        let cross = new THREE.Vector3().crossVectors(boatDirection, windHeading);

        return (cross.y > 0) ? -1 : 1;
    }

    /**
     * @brief Convenience function to get the relative angle of the wind on the boat
     * 
     * @param {THREE.Vector3} windHeading - the wind heading (normal vector)
     * @returns angle as a double in radians
     */
    getWindBoatAngle(windHeading) {
        return this.getHeading().angleTo(windHeading);
    }

    /**
     * @brief Gets the boat sail angle based on wind and sail angle
     * 
     * @param {THREE.Vector3} windHeading  - the wind heading (normal vector)
     * @returns boat sail angle in radians
     */
    getBoatSailAngle(windHeading){
        // magic formula based on trigonometry, simplified with various assumptions
        let boatSailAngle = Math.acos(-0.5 * this.sheet * this.sheet + 1.0);

        // prevent sail from blowing against the wind
        let windBoatAngle = this.getWindBoatAngle(windHeading);
        if (Math.abs(Math.PI - windBoatAngle) < Math.abs(boatSailAngle)){
            boatSailAngle = Math.PI - windBoatAngle; 
        }

        // jibe
        boatSailAngle = this.getSailSide(windHeading)*boatSailAngle;

        return boatSailAngle;

    }

    /**
     * @brief updates the sail direction based on the sheet length and wind heading
     * 
     * @param {THREE.Vector3} windHeading - the heading of the wind
     */
    updateSail(windHeading) {
        let boatSailAngle = this.getBoatSailAngle(windHeading);
  
        // Compute the difference between the current rotation and the target rotation
        if(this.mastCtrl == null){
        } else {
            // Update the sail's rotation
            this.mastCtrl.rotation.y = boatSailAngle;
        }
    } 

    /**
     * @brief Updates the speed target based on wind angle, boat angle, and sail side
     * 
     * @param {Wind} wind - wind object to pull heading and speed
     */
    updateSpeedFromWind(wind){
        let windBoatAngle = this.getWindBoatAngle(wind.heading);
   
        let sailSide = this.getSailSide(wind.heading);
        let sheet = this.estimateSheet( wind.heading)
        let forceMultiplier = Number(Forces.getHeadingMultiplier(sheet, windBoatAngle, sailSide))/100;

        this.targetSpeed = Math.min(wind.speed, this.topSpeed) * forceMultiplier;
    }

    //? updating boat position (goint to have to feed more inputs in order to control aplha/beta/gamma vals)
    /**
     * @brief updates the boat speed based on wind angle and sheet length
     * 
     * @param {THREE.Vector3} windVec - heading of the wind vector
     * @param {THREE.Vector3} waterCurrVec - heading of the current vector
     */
    updateSpeed(windVec, waterCurrVec ) {
        const bsAccelNDecel = 0.005; // Boat Speed acceleration and deceleration
    
        let boatDirection = this.getHeading(); // This is the boat's forward direction
        this.currentSpeed += (this.targetSpeed - this.currentSpeed) * bsAccelNDecel;
        //console.log("speed: ", this.currentSpeed.toFixed(2));   

        let alpha = 1;       // Weight for the boat's own direction (BOAT MOTOR)
        let beta  = 0;       // Weight for the wind
        let gamma = 0;       // Weight for the water current
    
        // drag forces
        let resultantDirection = boatDirection.clone().multiplyScalar(alpha)
                                .add(windVec.clone().multiplyScalar(beta))
                                .add(waterCurrVec.clone().multiplyScalar(gamma));
    
        // actually update position
        this.position.add(resultantDirection.normalize().multiplyScalar(this.currentSpeed));
        this.boatGeo.position.copy(this.position);
    }
    

}


export default Boat;


