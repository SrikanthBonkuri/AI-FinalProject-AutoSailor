import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';  // Ensure the path is correct based on your project structure
import { d2r } from './helperFunctions'; 

class Wind {
    /**
     * Constructs a Wind object
     * @param {THREE.Scene} scn - animation scene
     * @param {THREE.Clock} clk - animation clock
     * @param {THREE.Vector3} pos - world position
     * @param {double} hdng - heading of wind (radians)
     * @param {double} speed - boat speed (magnitude)
     */
    constructor(scn, clk, pos, hdng, speed){
        this.mainScene = scn;
        const dir = new THREE.Vector3(0, 1, 0)
        const length = 5;  // Length of the arrow
        const hex = 0xff0000;  // Color of the arrow
        this.debugWindGeo = new THREE.ArrowHelper(dir, pos, length,hex);    //* Wind Arrow visualizer
        this.position = pos;
        this.heading = hdng;
        this.speed = speed;
        this.clock = clk;

        //! CHANGE WIND ANGLES HERE!!!
        this.debugWindGeo.rotateX(d2r(90));
        this.debugWindGeo.rotateZ(d2r(0)); 

        this.addToScene();  
        this.getDirection();     
    }

    update(){
        // console.log(this.clock.getElapsedTime());
        // console.log(this.heading.);
        // this.heading.y = this.clock.getElapsedTime();
    }

    getDirection(){
        // Define the "forward" direction of the winds local space
        const localDirection = new THREE.Vector3(0, 1, 0);

        // Convert the local direction to world space based on the boat's current rotation
        // const worldDirection = localDirection.applyQuaternion(this.boatGeo.quaternion);
        // return worldDirection.normalize();  // Ensure the direction is normalized

        localDirection.applyQuaternion(this.debugWindGeo.quaternion);
        this.heading = localDirection;

        // console.log(localDirection);
        return this.heading;
    }

    addToScene(){
        this.mainScene.add(this.debugWindGeo);
    }
}

export default Wind;
