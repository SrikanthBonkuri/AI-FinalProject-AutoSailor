⛵


- parent new camera to boat and have a toggle between the parented camera and orbit camera.

- (think **clos** hit this bug but ill keep this here for future reference just in case) found a slight bug with the vectors affecting the boat... because is always calculating based on where the boat is facing (ie.BoatHeading). which we will need to change to something more like 

  1. Boat's Heading: This represents the direction the boat is facing, which can be thought of as its orientation. This doesn't always have to align with its movement direction, especially when external forces are acting on the boat.
  2. Boat's Movement Direction: This is the direction the boat is actually moving, and it can be influenced by various factors like wind, current, and the boat's own propulsion. This direction can be different from the boat's heading, especially in scenarios where the boat is drifting due to external forces.

  ```
    // Calculate the boat's movement direction based on various forces
    calculateMovementDirection() {
        let alpha = ...;   // Weight for the boat's own direction (propulsion)
        let beta  = ...;  // Weight for the wind
        let gamma = ...;  // Weight for the water current

        this.movementVector = direction.clone().multiplyScalar(alpha)
                            .add(windVec.clone().multiplyScalar(beta))
                            .add(waterCurrVec.clone().multiplyScalar(gamma));
    }

    // Update the boat's position based on its movement direction
    updatePosition() {
        this.calculateMovementDirection();
        this.position.add(this.movementVector.multiplyScalar(this.currentSpeed));
        this.boatGeo.position.copy(this.position);
    }

    // Update the boat's heading based on user input or other factors
    updateHeading(newHeading) {
        this.headingVector = newHeading;
        // ... other logic to rotate the boat's geometry to align with the new heading
    }
  ```

- (**clos improgress**) make sail be pushed by the wind... 
  - make sail reach wind vector and slowly and stop.  //
  - allow player to pull sail in towards center 
  - 

### **Sailing Model Features**

**Lee Helm:** When boatspeed is less than 15, apply a rotation to the boat [Lee Helm] that turns the boat away from the wind. (The convention is that negative rotation is away from the wind and positive rotation is towards the wind.) 
When boatspeed = 14.99, Lee Helm = -1*. This increases linearly (interpolation) to Lee Helm = -10 when boatspeed = 0 (including when speed is negative). 

* Lee Helm value is a bullshit number, it should be a very slow rotation that we can adjust via variable.

Lee Helm is only active when bow is pointed at <90 or >270 (i.e., when the bow is pointing at the upwind hemisphere).

**Weather Helm:** 

Apply a rotation to the boat [Weather Helm] based on the following mini-matrix (same x-axis values as main sail matrix).

[Insert matrix here]

If the sail is dropped, weather Helm stops running when the bow is pointed <90 or >270 (i.e., when the bow is pointing at the upwind hemisphere)..
