import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import * as hlpf from './js/helperFunctions' ;

import Boat from './js/boat.js';
import Wind from './js/wind.js';
import Agent from './js/agent.js';

const keys = {
    ArrowRight: false,
    ArrowLeft: false,
    d: false,
    a: false,
    i: false,
    o: false,
    w: false,
    '1': false,
    '2': false,
    '6': false,
    '7': false,
    '8': false,
    '9': false,
    '0': false,
    p: false,
};


let activeCamera; // Initialize with the default camera

//* Keyboard keypress Listeners
window.addEventListener('keydown', (event) => {
    if (keys[event.key] !== undefined) {
        keys[event.key] = true;

        switch (event.key) {
            case '1':
                // Code to switch to the default camera
                console.log("Default Orbit CAM Active!");
                activeCamera = camera;
                break;
            case '2':
                // Code to switch to the follow camera
                console.log("Follow CAM Active!");
                activeCamera = fcam;
                break;
            case '6':
                console.log("Reflex Agent Active");
                useAgent = true;
                agent.executeAgent(boat, wind, beacons, 'reflex');
                break;
            case '7':
                console.log("Greedy Agent Active");
                useAgent = true;
                agent.executeAgent(boat, wind, beacons, 'greedy');
                break;
            case '8':
                console.log("DLS Agent Active");
                useAgent = true;
                agent.executeAgent(boat, wind, beacons, 'dls');
                break;
            case '9':
                console.log("A* Agent Active");
                useAgent = true;
                agent.executeAgent(boat, wind, beacons, 'aStar');
                break;
            case '0':
                console.log("Manual Controls Active");
                useAgent = false;
                break;
        }
    }
});

window.addEventListener('keyup', (event) => {
    if (keys[event.key] !== undefined) {
        keys[event.key] = false;
    }
});


//* SETS the colors of the BG here!!! IMPORTANT to set the same color ass the ground
let setBG = document.body.style.backgroundColor = "#b4ad93";


//* seed based random usefull later (seed controled in the index.html)
let mySeed = parseInt(tokenData.hash.slice(0, 16), 16);
// console.log(mySeed);
// let R = new hlpr.Rnd(mySeed);
// console.log("MySeed: " + mySeed);
//* ##########################################################################

//* SCENE
const scene = new THREE.Scene();
const clock = new THREE.Clock();

//* CAMERA
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 30;
camera.position.y = 55;
activeCamera = camera;

//* FOLLOW CAMERA
const fcam = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
fcam.position.z = 30;
fcam.position.y = 55;
let lookAtPosition = new THREE.Vector3();

//* LIGHTS ######################################
// scene.fog = new THREE.Fog( 0xb4ad93, 50, 90 );
// scene.fog = new THREE.Fog( 0xffffff, 20, 75 );

// Ambient light
// scene.add( new THREE.AmbientLight( 0xffffff ) );
// const ambientLight = new THREE.AmbientLight(0x404040, 0.5); 
// scene.add(ambientLight);
// scene.add( new THREE.AmbientLight( 0x404040, 3 ) );

//* RAYCAST / MOUSE
var raycaster = new THREE.Raycaster();
var mouse = new THREE.Vector2();

var sphereBeaconGeo = new THREE.SphereGeometry(0.5, 32, 32); // Size can be adjusted
var sphereBeaconMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });


const hemiLight = new THREE.HemisphereLight( 0xffffff, 0xffffff, 2 );
hemiLight.color.setHSL( 0.6, 1, 0.6 );
hemiLight.groundColor.setHSL( 0.095, 1, 0.75 );
hemiLight.position.set( 0, 50, 0 );
scene.add( hemiLight );

const directionalLight = new THREE.DirectionalLight(0xffffff, 1); 
directionalLight.position.set(50, 100, 50); // Adjust as needed
directionalLight.target.position.set(0, 0, 0);

// Adjust the shadow camera frustum
directionalLight.shadow.camera.left = -100;   // Adjust based on your scene size
directionalLight.shadow.camera.right = 100;   // Adjust based on your scene size
directionalLight.shadow.camera.top = 10;      // Adjust based on your scene size
directionalLight.shadow.camera.bottom = -10;  // Adjust based on your scene size
directionalLight.shadow.camera.near = 1;      // Adjust if needed
directionalLight.shadow.camera.far = 2000;    // Adjust based on your scene depth
// directionalLight.shadow.bias = 0.01;
directionalLight.shadow.normalBias = 0.2;
directionalLight.shadow.opa
// Increase shadow resolution
directionalLight.shadow.mapSize.set(4096, 4096); 

// Add shadow casting capabilities
directionalLight.castShadow = true;
scene.add(directionalLight);
//* #######################################

//* sun light debug visualizer
scene.add( new THREE.CameraHelper( directionalLight.shadow.camera ) );


//* GROUND
const planeGeometry = new THREE.PlaneGeometry( 120, 80 );
const planeMaterial = new THREE.MeshPhysicalMaterial( {
    color: 0x93B4A6,
    roughness: 0.8,
    reflectivity: 1
} );

var checkeredUNIMS = {
    color1: { type: 'vec3', value: new THREE.Color(0xb6cde1) }, // First color (black)
    color2: { type: 'vec3', value: new THREE.Color(0xa8bccc) }, // Second color (white)
    scale: { type: 'float', value: 95.0 } // Scale of the checkerboard pattern
};
var checkerShader = `
    varying vec2 vUv;
    void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
`;
var chekerShader = `
    uniform vec3 color1;
    uniform vec3 color2;
    uniform float scale;
    varying vec2 vUv;
    void main() {
        vec2 scaledUv = floor(vUv * scale);
        float checker = mod(scaledUv.x + scaledUv.y, 2.0);
        gl_FragColor = vec4(mix(color1, color2, checker), 1.0);
    }
`;
var checkerboardMaterial = new THREE.ShaderMaterial({
    uniforms: checkeredUNIMS,
    vertexShader: checkerShader,
    fragmentShader: chekerShader
});

const ground = new THREE.Mesh( planeGeometry, checkerboardMaterial );
ground.rotation.x = - Math.PI / 2;
// console.log( Math.PI / 2)
ground.position.y = -0.25;
ground.scale.multiplyScalar( 3 );
// ground.castShadow = true;
ground.receiveShadow = true;
scene.add( ground );

//* RENDERER
const renderer = new THREE.WebGLRenderer( { antialias: true, alpha: true } );
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio( window.devicePixelRatio );
renderer.setSize( window.innerWidth, window.innerHeight );
renderer.shadowMap.enabled = true;
// renderer.shadowMap.renderReverseSided = true;
// renderer.shadowMap.type = THREE.VSMShadowMap;
// renderer.shadowMap.type = THREE.PCFSoftShadowMap;
// renderer.setClearColor( 0xffffff, 1 );   //* MAIN BACKGROUND IF webGL alpha is set to false
// renderer.setClearColor( 0xe1aee3, 1 ); 
document.body.appendChild(renderer.domElement);

renderer.domElement.addEventListener('click', createBeacon, false);       //* Left Click Event to create Beacons
renderer.domElement.addEventListener('contextmenu', clearBeacons, false); //* Right Click Event to delete all Beacons

//*
//* Create wind
const wind = new Wind(scene, clock, new THREE.Vector3(0, 15, 0), 0, .25);

const wLabel = hlpf.createTextLabel('WindDir', new THREE.Vector3(0, 15, 0));
scene.add(wLabel);

//* Create the boat & boat TEMP motor propulsion with spaceBar #######
const boat = new Boat(scene, new THREE.Vector3(0, 0, 0), hlpf.d2r(150), 0, () => {
    // Any other logic you want to run after the boat model is loaded...
    console.log("loaded boat geo!");
});


//* Maybe we can start game logics here in the future 
function init() {

}

//* Temp Orbit Camera (left click to orbit / right click pans / scroolWheel zoom)
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 5, 0);
controls.update();


/** ======== Auto Sailor Stuff ======== **/
// Auto sailor
let agent = new Agent();
let useAgent = false;

// beacons for autosailor
let beacons = [];
function createBeacon(event) {
    if (useAgent) { return; }
    event.preventDefault();
    console.log("createBeacon!");
    // Calculate mouse position in normalized device coordinates
    // (-1 to +1) for both components
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;

    // Update the picking ray with the camera and mouse position
    raycaster.setFromCamera(mouse, activeCamera);

    // Calculate objects intersecting the picking ray
    let intersects = raycaster.intersectObjects(scene.children, true);

    for (let i = 0; i < intersects.length; i++) {
        // Check if the intersected object is the ground
        if (intersects[i].object === ground) { // Assuming 'ground' is your ground object
            // Add the sphere at the intersect point
            let sphere = new THREE.Mesh(sphereBeaconGeo, sphereBeaconMat);
            sphere.position.copy(intersects[i].point);
            scene.add(sphere);
            beacons.push(sphere);

            break; // Exit the loop after adding the sphere
        }
    }
}

function clearBeacons(event) {
    event.preventDefault();
    console.log('Beacons Deleted.');
    // Remove all spheres from the scene
    beacons.forEach(sphere => {
        scene.remove(sphere);
        // If using a Physics Engine or need to dispose geometries/materials, do it here
    });

    // Clear the array
    beacons = [];
    
    // TODO: reset agent here?
    agent.reset();
    useAgent = false;
}

/** ======== End Auto Sailor Stuff ======== **/

/** ADDITIONAL KEYBINDS (DEFINED AT TOP OF INDEX)
 * '1': default camera
 * '2': follow camera
 * '6': Reflex Agent
 * '7': Greedy Agent
 * '8': DLS Agent
 * '9': A* Agent
 * '0': Manual Controls
 */
//* Animation loop (this is always being called like a tick event)
const animate = () => {
    // const delta = clock.getDelta(); // Returns the time since last tick in seconds
    // console.log(delta);

    // follow camera
    lookAtPosition.set(boat.position.x, 0, boat.position.z);
    fcam.lookAt(lookAtPosition);
    fcam.position.x = boat.position.x;      // if we turn off these two it just looks at the boat
    fcam.position.z = boat.position.z + 30; // if we turn off these two it just looks at the boat (30 equals the same as fcam initial Z-POSITION)

    // keybinds
    if(keys.cam){}
    if(keys.ArrowRight || keys.d) { // boat right turn
        boat.updateHeading(-boat.lrTrnSpeed);
        useAgent = false;
    }
    if(keys.ArrowLeft || keys.a) { // boat left turn
        boat.updateHeading(boat.lrTrnSpeed);
        useAgent = false;
    }
    if(keys.i) { // sheet in
        boat.sheetIn(wind.heading);
        useAgent = false;
    }
    if(keys.o) { // sheet out
        boat.sheetOut();
        useAgent = false;
    }
    if(keys.w){ // timestamp for debugging
        console.log(wind.clock.getElapsedTime());
    }
    if (useAgent) {
        if (!agent.performNextAction(boat, wind)) {
            beacons.forEach(sphere => {
                scene.remove(sphere);
            });
            beacons = [];
            agent.reset();
            useAgent = false;
        }
    }

    //* move the boat
    // TODO make this one function call
    boat.updateSail(wind.heading);
    boat.updateSpeedFromWind(wind);
    boat.updateSpeed(wind.heading, wind.heading);
    
    // do the animation
    renderer.render(scene, activeCamera);
    window.requestAnimationFrame(animate);
}

animate();
